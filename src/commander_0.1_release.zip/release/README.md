# commander
Keep the commands.
该工具用于保存常用的指令，所以叫指令长没毛病。

# user guide

## 配置文件
目录下有一个配置文件: commander.ini
需要注意的是第一个section：

```
[BaseInfo]
tapnum=5
```

tapnum: 可以手动修改，重启app后tap的页数会根据此配置增加。初始配置了5个。

## 基本用法
1. 单击按钮：自动复制按钮保存的指令到剪切板
2. ctrl + 单击：将下方名称栏和命令栏的内容存储到按键。

## Tap重命名
在名称栏输入名称。
ctrl + 双击tap页面的标题，可以将tap的名称修改成名称栏的内容。

## 透明度修改
拖动下方滑块可以改变app的透明度。

## help
点击右上角的help会弹出帮助选项，并将github地址复制到剪切板。